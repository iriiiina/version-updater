#!/bin/bash

##################################################################################
### This is file with environment specific functions                           ###
### It requires modifications and should be filled according to environment    ###
### File can be downloaded from HG repo:                                       ###
###    http://ehealth.webmedia.ee/scripts/version-updater/functions-local.sh   ###
###                                                                            ###
### Author: Irina.Ivanova@nortal.com                                           ###
### Last modified: 4.02.2016, v6.0                                             ###
### Version-updater manual:                                                    ###
###    https://confluence.nortal.com/display/support/Version-updater+Script    ###
##################################################################################