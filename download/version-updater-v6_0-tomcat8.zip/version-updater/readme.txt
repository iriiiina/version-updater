Manual: https://confluence.nortal.com/display/support/Version-updater+Script
