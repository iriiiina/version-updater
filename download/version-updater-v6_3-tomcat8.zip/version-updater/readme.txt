Author: Irina Ivanova, iriiiina@gmail.com
Manual: https://iriiiina.gitbooks.io/version-updater-manual/content/
